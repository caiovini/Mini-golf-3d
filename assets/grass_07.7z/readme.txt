Provided by Nobiax.

Absolutely free to use or to modify in any kind of work (personal, commercial or else).

Give me a link of the result at nobiax.deviantart.com or my other account on OpenGameArt.com or ShareCG.com
( watch my journal on deviantart ) ;)
